//非同期処理

/*
 ・実行中に別の処理を止めない処理のことを非同期処理（ex:コンビニで弁当を温めてもらいながら会計をする）
 ・処理の高速化やレスポンシブなGUIの実現につながる
 ・Swiftでは、スレッドを利用して非同期処理を実現する。スレッドは、CPU利用の仮想的な実行の単位。通常、プログラムはメインスレッドという単一のスレッドから開始する。メインスレッドの処理とは並列に、複数のスレッドを使用して処理を並列に行うことをマルチスレッド処理という。ただし利用には注意が必要。
 ・Foundationは、Treadというクラスを提供している。また、libdispatchがていきょうするGCDによって、スレッドを直接操作しなくても非同期処理ができるようになっている。libdispatchの利用にはDispatchモジュールのインポートが必要。
 ・非同期処理の方法まとめ
    １　GCD
    ２　Operation,OperationQueueクラスの利用
    ３　Treadクラスの利用
 
 １　GCD（非同期処理のための低レベルAPI群）：あらかじめ準備されたスレッドを使い回すスレッド管理＝スレッドプール
 GCDのキューはディスパッチキューという。ディスパッチキューはタスクの実行方式によって２種類に大別される。
    １. 直列ディスパッチキュー：現在実行中の処理の終了を待ってから、次の処理を実行する
    ２. 並列ディスパッチキュー：現在実行中の処理の終了を待たずに、次の処理を並列して実行する
 ディスパッチキューを利用するには、既存のディスパッチキューを取得するか、新規のディスパッチキューを生成する。
 
 ・既存のディスパッチキューの取得：GCDは既存のディスパッチキューとして、１つのメインキューと複数のグローバルキューを提供している。
 ・メインキューはメインスレッドでタスクを自行する直列ディスパッチキューである。
 ・グローバルキューは並列ディスパッチキューで、実行優先度を指定して取得する。優先度をQoSと言い、優先度の高い順に次の５種類がある。
 ①userInteractive
 ② userInitiated
 ③default
 ④utility
 ⑤background
 
 
 */

import Dispatch

let queue1 = DispatchQueue.main //メインディスパッチキューを取得

//どういうときにGCDを利用するべきか
//GCDではタスクをクロージャとして表現できるため、単純な非同期処理の実装に向いている。

import Foundation

class SomeOperation : Operation {
    let number: Int
    init(number: Int) { self.number = number }
    
    override func main() {
        Thread.sleep(forTimeInterval:  1)
        
        guard !isCancelled else { return }
        
        print(number)
    }
}

 let opQueue = OperationQueue()
opQueue.name = "com.exmple.my_operation_queue"
//タスクは最大２個まで並列に実行される
opQueue.maxConcurrentOperationCount = 2
opQueue.qualityOfService = .userInitiated

var operations = [SomeOperation]()

for i in 0..<10 {
    operations.append(SomeOperation(number: i))
}

//trueにすると処理が終わってから63行目が出力される
opQueue.addOperations(operations, waitUntilFinished: false)
print("Operations are added")
//6が出力されない（タスクが１つキャンセルされた）
operations[6].cancel()

